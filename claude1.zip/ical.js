// api/ical.js — Lee un calendario iCal (Airbnb, Booking, Google...) y lo devuelve al sistema.
//
// Antes: descargaba CUALQUIER url que le pasaran (proxy abierto).
// Ahora:
//   - solo http/https en puertos normales, sin usuario:clave en la url
//   - bloquea direcciones internas/privadas (localhost, 10.x, 192.168.x, 169.254.x, etc.)
//   - revisa también las redirecciones (máx. 3)
//   - tiempo máximo de 8 s y tamaño máximo de 2 MB
//   - comprueba que el contenido sea realmente un calendario (BEGIN:VCALENDAR)
//   - opcional: limitar a dominios concretos con la variable de entorno
//     ICAL_ALLOWED_HOSTS="airbnb.com,booking.com,calendar.google.com"

const dns = require('dns').promises;
const net = require('net');

const MAX_BYTES = 2 * 1024 * 1024;
const TIMEOUT_MS = 8000;
const MAX_REDIRECTS = 3;

function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return (
      a === 0 || a === 10 || a === 127 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      a >= 224
    );
  }
  if (net.isIPv6(ip)) {
    const v = ip.toLowerCase();
    if (v === '::1' || v === '::') return true;
    if (v.startsWith('fc') || v.startsWith('fd') || v.startsWith('fe80')) return true;
    if (v.startsWith('::ffff:')) {
      const m = v.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
      return m ? isPrivateIp(m[1]) : true; // forma hexadecimal: por seguridad, se bloquea
    }
    return false;
  }
  return true; // si no se puede identificar, se bloquea
}

function allowedByList(hostname) {
  const list = String(process.env.ICAL_ALLOWED_HOSTS || '')
    .split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
  if (!list.length) return true;
  const h = hostname.toLowerCase();
  return list.some(d => h === d || h.endsWith('.' + d));
}

async function assertPublicUrl(raw) {
  let u;
  try { u = new URL(raw); } catch (e) { throw new Error('url inválida'); }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error('url inválida');
  if (u.username || u.password) throw new Error('url inválida');
  if (u.port && u.port !== '80' && u.port !== '443') throw new Error('puerto no permitido');
  if (!allowedByList(u.hostname)) throw new Error('dominio no permitido');
  const host = u.hostname.replace(/^\[|\]$/g, '');
  const addrs = net.isIP(host)
    ? [{ address: host }]
    : await dns.lookup(host, { all: true });
  if (!addrs.length || addrs.some(a => isPrivateIp(a.address))) {
    throw new Error('dirección no permitida');
  }
  return u;
}

async function readLimited(response) {
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.length;
    if (total > MAX_BYTES) {
      try { await reader.cancel(); } catch (e) {}
      throw new Error('calendario demasiado grande');
    }
    chunks.push(value);
  }
  return Buffer.concat(chunks.map(c => Buffer.from(c))).toString('utf8');
}

async function fetchIcs(startUrl) {
  let current = startUrl;
  for (let i = 0; i <= MAX_REDIRECTS; i++) {
    const u = await assertPublicUrl(current);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
    let r;
    try {
      r = await fetch(u.toString(), {
        headers: { 'User-Agent': 'FLYHOUSE-Life/1.0' },
        redirect: 'manual',
        signal: ctrl.signal
      });
      if (r.status >= 300 && r.status < 400 && r.headers.get('location')) {
        current = new URL(r.headers.get('location'), u).toString();
        continue;
      }
      if (!r.ok) throw new Error('el calendario respondió con error ' + r.status);
      return await readLimited(r);
    } finally {
      clearTimeout(timer);
    }
  }
  throw new Error('demasiadas redirecciones');
}

module.exports = async function handler(req, res) {
  // El sistema llama a esta función desde su propio dominio, no hace falta CORS abierto.
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'GET') return res.status(405).json({ ok: false, error: 'método no permitido' });

  const url = String((req.query && req.query.url) || '').trim();
  if (!url) return res.status(400).json({ ok: false, error: 'url inválida' });

  try {
    const ics = await fetchIcs(url);
    if (!/BEGIN:VCALENDAR/i.test(ics)) {
      return res.status(422).json({ ok: false, error: 'El enlace no parece un calendario iCal' });
    }
    return res.status(200).json({ ok: true, ics });
  } catch (e) {
    const msg = String((e && e.message) || '');
    const known = /url inválida|puerto no permitido|dominio no permitido|dirección no permitida|demasiado grande|redirecciones|respondió con error/.test(msg);
    const status = known ? 400 : 500;
    return res.status(status).json({
      ok: false,
      error: known ? msg : 'No se pudo leer el calendario'
    });
  }
};
