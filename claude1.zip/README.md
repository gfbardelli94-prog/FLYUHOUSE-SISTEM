# FLYHOUSE — Property Service

Sistema web (SPA) en `index.html`: Store, Rental, Life, Presupuestos, Requerimientos, Contratos, CRM.
Los datos se guardan en el navegador (localStorage) y se sincronizan con **Supabase** (tabla `system_data`).
Las funciones de `api/` generan las vistas previas de los enlaces y leen calendarios iCal.

## Estructura del repositorio

```
index.html        ← la aplicación
vercel.json       ← rutas y cabeceras
api/
  ical.js         ← lee calendarios iCal (Airbnb, Booking...) de forma segura
  og.js           ← imagen de vista previa (WhatsApp, etc.)
  share.js        ← página de vista previa de /s/<token>
  rental.js       ← página de vista previa de /r
README.md
```

## Subir a Vercel (con GitHub)

1. Crea un repositorio en GitHub (ejemplo: `flyhouse`).
2. Sube todo respetando la estructura de arriba (la carpeta `api/` va en la raíz).
3. En https://vercel.com → **Add New Project** → elige el repo → **Deploy**.

### Actualizar
Edita o sube el archivo en GitHub (lápiz → *Commit changes*). Vercel republica solo en ~1 minuto.

## Variables de entorno (opcionales, en Vercel → Settings → Environment Variables)

| Variable | Para qué sirve |
|---|---|
| `SUPABASE_URL` | URL de tu proyecto Supabase (si no existe, se usa la actual) |
| `SUPABASE_ANON_KEY` | Clave pública (publishable) de Supabase |
| `PUBLIC_ORIGIN` | Dominio público de la app, p. ej. `https://flyuhouse-sistem.vercel.app` |
| `ICAL_ALLOWED_HOSTS` | Lista separada por comas de dominios permitidos para calendarios, p. ej. `airbnb.com,booking.com,calendar.google.com` |

## Acceso y seguridad

- **No guardes PINs en este archivo ni en el repositorio.** Cambia el PIN del usuario Master desde el panel de usuarios.
- Pendiente (siguiente etapa): mover el login a Supabase Auth y activar reglas de acceso (RLS) para que los datos de clientes no sean públicos.

## Presupuestos online

**Copiar link cliente** genera un enlace `/s/<token>` con vista previa. Usa imágenes comprimidas: las fotos muy pesadas hacen más lento el sistema.

## Abrir en local

Abre `index.html` en Chrome/Edge. Las funciones de `api/` solo corren en Vercel (o con `vercel dev`).
