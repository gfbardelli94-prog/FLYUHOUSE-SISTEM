// api/og.js — Imagen para la vista previa de los enlaces (WhatsApp, Facebook, etc.)
//
// Mejoras respecto a la versión anterior:
//   - Si no hay foto (o es el enlace de Rental) devuelve la imagen de marca FLYHOUSE
//     de 1200x630, en lugar de un píxel de 1x1. Para "rental" ni siquiera consulta la base de datos.
//   - Solo sirve imágenes rasterizadas (png, jpeg, webp, gif). Se descartan SVG y otros tipos.
//   - Imágenes por URL: solo https, sin IP directa ni localhost, con tiempo y tamaño máximos.
//   - Cabecera nosniff para que el navegador no reinterprete el contenido.
//   - La URL y la clave de Supabase pueden ir en variables de entorno de Vercel
//     (SUPABASE_URL, SUPABASE_ANON_KEY); si no existen se usan los valores actuales.

const SB_URL = process.env.SUPABASE_URL || 'https://zzyadghmqqokxchngltw.supabase.co';
const SB_KEY = process.env.SUPABASE_ANON_KEY || 'sb_publishable_AMxXlzxoO2sVyaVfsns0VQ_Q49mRMW_';

const RASTER = /^image\/(png|jpe?g|webp|gif)$/i;
const MAX_IMG_BYTES = 5 * 1024 * 1024;
const TIMEOUT_MS = 6000;

const BRAND_PNG_B64 =
  'iVBORw0KGgoAAAANSUhEUgAABLAAAAJ2BAMAAAC9bmZvAAAAMFBMVEXm5ubS0tK9vb3UrzfPqzbMqTW1nEmTg1B1ZjhdUCVHPiM6MRUyMjMmIhYPDw0KCguwOb6fAAAXcUlEQVR42u2dbXAc5X3A/3unF5owzUnCdmZCpyfhF3WGTAQIcGba1GBi0hnPRAbzkkxnKhtKcUhb2QSDDMbGDhY42FZb3oKT+D4ZY4Mt2s4wIGLUfGgTLIOadKbGNtJ9SGZio5drQyh6u+2HO0m3z749J93u3Zrf75Nub/fZ1T6/+///z3N7u4YpAKUnxikAxALEAsQCQCxALEAsAMQCxALEAkAsQCxALADEAsQCxAJALEAsQCwAxALEAsQCQCxALEAsAMQCxALEAkAsQCxALADEAsQCxAJALEAsQCwAxALEgkuXKqeFrZwXKILL+4hYUM6IJf2cGNDm47XUWEDxDogFgFiAWIBYAIgFiAWIBYBYgFiAWACIBYgFiAWAWIBYgFgAiAWIBYgFiAWAWIBYgFgAiAWIBYgFgFiAWIBYAIgFiAWIBYBYgFiAWACIBYgFiAWAWIBYgFgAiAWIBYgFgFiAWIBYAIgFiAWIBYBYgFiAWACIBYgFiAWAWIBYgFgAiAWIBYgFgFiAWIBYAIgFiAWIBYBYgFiAWACIBYgFiAWAWIBYgFgAiAWIBYgFgFiAWIBYAIgFiAWIBYBYgFiAWACIBYgFiAWAWIBYgFgAiAWIBYgFgFiAWIBYAIgFiAWIBYjFKQDEAsQCxAJALEAsQCwAxALEAsQCQCxALEAsAMQCxALEAkAsQCxALADEAsQCxAJALEAsQCwAxALEAsQCQCxALEAsAMQCxALEAkAsQCxALADEAsQCxAJALEAsQCwAxALEAsQCQCxALEAsAMQCxALEAkAsQCxALADEAsQCxAJALEAsQCwAxALEAsQCQCxALEAsAMQCxALEAkAsQCxALADEAsQCxAJALEAsQCwAxALEAsQCQCxALEAsAMQCxALEAsQCQCyICFWcgpIwfHJo0MwMNdYZTfWrG8twAOdOjg1mRmMJo66urqk1iViXAmbv2ydzfw2K9MsPW6/fGO4BZA/2v5/7a1RERIyrrl16c6Ks58QwHRa29hff0L/u1Fnr6pT3dlf2eJ/ANRnL67/s0Ftv7c5i9ves5SD/tNvvn3rz2IC6aOmtG3w2mlpp6YZT9v/hBsvLtz08efNg2r6wYfX1N+nt3LVMelev6z9e2xf1iBVrs4p5zEWscatXsfYAj+mjg8ftC8+fP7U1rHSUfeq40+KRo0eXrV5ftrAVseL9duvLyYzzaj9WPj0B9vHZTY7dKu/e3RfOKZnac9y17nrxrmcyiKXDEusnMJty/gwrfXpDcAf05nfSbh3+8KFw4pVX9TBy5BuIpZcLra9fdVxrwtrZsY7AjufMo+4RYfqFVAjjhq4eH/EQq3S58NWwMuGF73r26Qs9gZ+PMycqNQRETKxF1lw47RQUzJ6QMuHEA94VzPRT6YBPx+R2QaySULXK+vqkfyY0gsqE2W1+3kw9GvDp+GEasUrEPUoyclil1/qyOqhMeMR/3PfBgUBPxnhKEKtUuVD8cqGZCicTju/XWOnlQCcdDgpilSwXtvnlwpAyoamV5rI/CrLCSiFWYLnwbLky4W/1YtEHAY4M3xLECiwXTqV8xoTXB1S5a47HzL2BnQnzBGIFmAvfUfPDgDUTbg7mMM4M6M5JBJavJgYQK8RceC6UTGju1141sAr7vCBWgLlwUkl9B0LJhBf0o8VEUAPDE4gVaC484ZUfjHXBHEQRgz3zJwFVeT2IFWIuVPKDOlNfqvKmmE79IBPMZENlf/wjKJaaC/sK5VHCQ0Czo+ccPqLrl16THOs//ZrtnelURxDHMKIuWHZNa2PdF8ZGT472pxFrXrnQGi9OrCq0zLpuMJnQtH9Ts3xPUkTq16y592lbTXUsELGUqeGq+3IX2tfXLxWz18FvUqEvyk8VCq8X/0gZEwaUCW2l+42HZ0afi/baZJ4MJIBYG60+UnBWjDWdb9x+SUasKwMtLBer/ZYMORP22uLVcwWf1c4xJWZlUzsDOAiL3LGupFIvdN7+kuZw1OGXHJ/RiKWMC83u2T+nesLIhKJ+bKr2WM7pHqWT5e0gBoWWiLXSHpqX/+BeUuHCcuG7IWfCSTUT3m01qWZXCAO4KUs3bnGKRPcfbkGshYwLp2Y/vD8OJRMq+kqNWpw3Kx06HUBlYPlBqMvV18tfug2xiqG6TalhZgwLZUwo6u+t7rOdVTWAnAhYrGVu3du5EbEWkAtnimnltxUBZUJT0be63bZKsxJBzgVQYxW+cL1bhHE/Yi0gF84IFU4mnEr77kb9mdp06Y9itPBFsuJ6KKJiOefCbDiZcEo5hU4X5tyhiNVX8qPIVHYPRfX+WEouzP2SULkoOaBMKD9V5hqcwkWNsnAg2NORQKxgcuFERsR2ycHygPY9oJFwDSUXvhPs6cggVoC5UM2EG4LZtamI5RwXb/eeoVg4acQKKxdOhpMJp627ibc5rlXlMYaTYC1DrBKPC4+FkwmnPQ2a1brFulHJY4qliOtHrIBy4XSP7ec568IRa6nLalaxzL5Az8ZkBrFKhfJlxXHbmLAtoB0r10Fd47LauoCTlWUgOH0IsUqF8i3GRfValqAyoapIi8tqDQHPN9RbXr2SRqxS5UJrbT51KKRMqIgVW6V3ZgdLfRiG9d/flkGsYMaFbw2EkwkVseKu4ntWZiXvubOb+hCrNChV87mQMqGZ1juBRkuw8w2G8vrc1h+kEasU1KzyejewTDilNdugzgeIGXjPZV+5a+87iFX6XBhSJjT1BoWqWCWPWPGkbdH00a2bflQhtVZAP6b4davjYq/HKyw4F84nE7ocZxFiJV1XVFJhOlniVJh0yHzmqVPHVt9Z5J5M55Pw+X/7rEYsr1wYWCZUQ4/7R6XRc5Zi4bjMc4wcvbOzAu7qEOnHym0sQyZUI1ZC99SWPEXd7Kp+75Obyq5WpJ/+5Z4LlwW301GtuGEftpVcrAaP9071n9qaKGvfRDpiuefCAH+cktGNWEGL5XnnL/Otb5xArJLnwqrgMqFSKxnaYpW+61Z5vj3VtR+xSp0Llwe4z8w87Sn9NIBPWM4efgax5psLW4qsa0uOof1W6cVa7LfCkccRa55scc6E7ZUQsYJOhRr/5hsHEKuUuXC5fDb4a78VTI2nsiCWfi4MLxN6haWg57H8vi0VEZnei1jzY3PYmbCSMB7yXeXiAcSaF8tCz4SZCvrvl7T5rnIUsUqWC4PNhIlK+vcfTvqtMdmNWCXKhZ+ZTCgi1d+v1JAVebGWlXdM6HH9nvZlEAuheYtvyOpDrHl9ZlvKOCasAL7ld2e1Mj0jLPJi2Z7uFQ84EyZ0I5YZzv+/6R6fNU4hVkly4YpQ964vViIws570bnoqg1ilyIVBZ8JEyNv5c+vhm7zeLs/DnKIvlvJ8r6AzofobiUyZU6GIyOK9D3lNOwyUo1si+WQKJUTtsIi18ON8NlVE5MnoRqJEkB+uu+44eMrVH79b0fBkioqgXjccZMMTSyT2NwcfcisCpstxmqowpdjooESskIp3382Nu+7s7T+uYTg1VmWifdHCoFdtpjRj+umgc3GXsWbby07P/Cr9Td8QK/iIldasmWNJz1Yzxe3VjWWdbzhcsNyHWNET633XFdNlOdGLtj2ZLNZaxKoElGHnlKZYPiEnU7rZilufTyJWFGuspF5lrNy1O1ZsbjPnkwpFRGTxc4gVRZJ6Y/lJz0AnRlKzVCteLFnyhBTVOGJVoFhZt8pYCWVN3vMH6RJGLJE1FTd4hmLFcp0h1b7HQ6lrLLHdE4VUGAlu1hsWHvfUUV2Q8Yl4Rf5IcSNiRX5YeN5lNWskM1Z5N5r2iXhFilVfsuCHWBU236A8kDye8K6xhnzEjC+kWw3EioRYyrCwx3GtKb/znPTR0ypW3UK6NYlYUUC5z7bLFyavWV8usq3Q4jWGtCXHxqh1K2IVjyLWu07rqE+Msl/jab0hn+2L4uxA2YMOYoXMaiXppR3WUZ4Y5TDbYD3ztumwSa+KTERkyuu+almfjRGrElGfcel0ewTl2Ylx+6DQ8E6oI9aXDoPKl/frikWNFRGxkr65UP0BQ9xXT/X6Yes0mNNFN+Zhd7PMsp8kxJpH9a6Ej8mUbZUzSiZ0uHdJzJodlUdZKmY6zzYcftTtEEdIhVFEvZbuJVvAUmOJ0/MMlFkLq50XMjrd9OZ3Ms5v/IRUGEXUuYOJbjVgDSiZsM1/cPmKJZXts755hcuRvOv8MLkpS7wzWhArGtjuF3HEmvkm1JvKVmsMLicLxwBn+vxmK/Kc2+pUaL1l7WNSYVRQA9DUNksi3KtOQNzi1IhaNxXcL/TidvGbrZjd2WF70JrYX/4+rrCff7k+jeu77ZV0mF/fqSw4+8DcVZvZrh710+t48NUJa4E0/fAj+VLs7La072zFHKdOr7c+72tKqbz8vmc03U56zb8TscLFfh/BX3x7xoWPttruG+T8cBJ1cCnTezpfHTJHe7u+nRYpQo3s0TsLn4B59n6lwltKxIrMhMPmv1IXnb1z/dJrkmP9p1+zr36Hcyvr1Mhm9vY6r+n3zKns0aNLr62/ua5ubOS988dFO48iVqWxzKlz3VZ2u0+JfiS5yX+V8+flRc2KkOK9gnNhMZ21wmVU5vn4Lh0zNWNHErGiw71F5E23mzn6PL7LZ7aiwpMSYs2PJfqFi/vzI+7RbGH9gg71FsSKUvm+RXtV9yfe1OolqYVlwlg7YkWJZt2QVePesZq5cFEieiUWYs37xO3WDG1b5xXM5lnPOVCmH68i1nz5ol64WeE1fqzVGVwWNQK159EOxIpYlfWQ1vm9d8HB6L4FHeaKBGJFbWCoU79/yzuufdE/Gi1eWOm+URAratztnwyXb/ZZYatvB21d0DE2r0Ks6NXve/wGXFV7fAuoXT4rrFyQGfFdgljRo+Y57wIm/oj/UP8vvJPhYlczYrdpHOGmJGJFssx61vPc3q8xnjMebvEKec+7qhvrfNLXmpXtgliRpNnjAUnxTRt0mqh+3t2s+FMe7hi3vni7z4jwWUGsiGK/k+xssHl6g14TNXtaXJvwLrCu6Dzs9UiqG58TxIosy19wrnVuOKJddS9+ad5NLH96j9u1WrG7fSrAYOFCv4WyaNt1xwbUhUvXFDN/FOt0aOKK9Tqzp8aar/c6XbQq19+1qqynxXD6MXZrP74Ug9n79snCc9p6fdHTkubR0yctXdC6Xj/eDL82eDpjMXX1DevC+/c/XtuHWEExfHJo0MwMNdYZTfWrG+fXxPGxwTEZajTqGuuX3lTkxtmfDo6NDcloLGE01TXdEmoSRCwITyyKd2BUCIgFiAWAWIBYgFgAiAWIBYgFgFiAWIBYAIgFiAWIBYBYgFiAWACIBYgFiAWAWIBYgFgAiAWIBYgFgFiAWIBYAIgFiAWIBYBYgFiAWACIBYgFiAWAWIBYgFgAiAWIBYgFgFiAWIBYAIgFiAWIBYBYgFiAWACIBYgFlwxVn91/vTWEfVzeR8QCIGKVgn56n4gFiAWAWIBYgFgAiAWIBYgFiAWAWIBYgFgAiAWIBYgFgFiAWIBYAIgFiAWIBYBYgFiAWACIBYgFiAWAWIBYgFgAiAWIBYgFgFiAWAulzjAMI9awfeb1/xqGYRgNzQMF64w82BS7arvfNoZhdBe+P7dFozHLF0Tkl4YRS4uIPGEYl6nHk93dZDQ079Ns+neGEc/9tdkw/nhmjZ1zrT3VZDR0ZgqP2zCMP4heN5kOXGdWMon8kV+df/0/M5+RodlVfpsUEZFm323kgPX9L+ffT86doD80TfNTEdlhmuZ0QuSPlMPJduTWu1Kv6SkRGZrZx46ZNXbMtDaV23Pt+9aNL6vkDvndnzssjHAq/K9uJXJ8bfavlWkRETnzFb9tbO+nHRfXJkX2icjvMyK7lPd+nW9yWLSajiVEUiIi02mRNtvH/Hu5tcbbSYXlY7vy+jc2PeyebPeJ323Oy18X+SQj8p5ITO3y/bqpIde00S7SIyIyKRJrERdLqbHKySdqsZPXyPzm7JJv+m2jMui8eIVItlvMNpEvqTvVViHfdJvIhyIiEyLVtnW+RvFeVnaYwx0i2dlyvdYc+QcRyZe842mR2Gsj/ygiZ722MU3T7Jh7P/tBQsTMvRjKvfWVmZoplwvHMyJblEOZFJHHRoe7EoWZ06vpa3PbyPsiNer/NZ4WkccGh19IFB63aZr/h1gh0dAlIn1zr+sfEJG8NB+IyL7b6v+2Q2Q847GNgrG8R2Ta5c0ekU/kFyKxDjXDidTurmt4ZLjD42gLm64Wmci32KSud0FEvry7seH+M21ErDJRMxehcn0nIvmSJSVS2yEiu0TMlNc2KgmRuMtbzSLZA+32TJhXRSTe5Xm4c03XiJgDuSOzVeiHRGI/ExFZshOxKmXaJNd7+VhQIyLyeckPwHTJ5Px0Gxc+nbZnQjFyZb1+07GkSI/IZMZBrJTI5xLUWGVlYk4kEZHsc7kuExEznU8ysaQSoCzbjBvG7FxljrNtDtmpoM8vOGRCqRLJNu+zquXddLvIIZHx3MyD9cORFrlK3cEThmEYLYgVEiOdIrJqrifjfz+bprIyM0HUJjLmuo29A1dkxOhxe/tGmQmCVuJJkQvfa9jmFbWsTW8QuSgyKvI5db25IydilYcnjCu6bdNAuepktqSZy5Ae26hcnRSPXGifHRWRfxYRyXY1p32OebbpxSITIimRepdiDLHKjPUTb5xOzn3uEzOdZHpuo3LlL90HdilxyoQiV+eWXfgz0Wy6WiSblpTIBqeIhVjlZ7e1QPlqwb+UcSvGd3u26DXxfaOLlsa+XBj7TVqz6XhCpCebdsh6MZ9RK2KFwtVK+Pg0ZRmEzc1COG9Ta5qmqU5bbXPfXW1C5EHHU7h9uCtpmdnwabpdJDXplpVtYu0wTdMcQKywqH/sVwWdnv0PEXl87l/qmZl3qHPdxtaBwx0in7qHHcN904ZHzidm9qnRdJvIoOMXOnNHTsQqDztMc8SS1IyVHSIX838nRYZEct8dJty3senRpU6o6hPv8Exi1qavFZl4z+ELHTGS+e8REaty2JX/pi0XEcZFRH4vDnOQHlyW1L9WYZaJHSK5WYyMbtM1IpM9jlNmbXqzrYgVIrUyO83eLjLenUuNRjFiSUf+a7xiMHc/ns+6Cd2mq0WyKUfnN89cVXZhJ2JVCDVJkUO5P1eIyIPvjf5Tt0hNUaP3jSITmeLN+pP3Rn/e7SNWYdO5bwScnF8iIr/aPjTyYnMPYlUK7bNFVm1SJHtdw9/lHXNh3LB9V1IzvyLrzHUNX7VkXb+mO0Scna9Nisj3m67YVKD3E7bvhxArVDbMXiRjvD77371eXNRLiByY7/69s66l6XX5hGjnZ5dMd1w6Yi2eiwmz3564f0Pj6sbF+e7/SwntpheLiDQ4rXZlB2JVXPWemK3eYz/PdXLzfxbZxubiq/ea/NeHsX/Rb7pa3MarxjO5j0IshViVgtE+Nwm05PyWOqPpsf+eR9Sbu3ZZc7fbh7c0St2K0y36TceT4nYZQ/zDXY1S/8iHLZHvDtNhYWu/AOjy8dq+SzliAakQEAsAsQCxALEAEAsQCxALALEAsQCxABALEAsQCwCxALEAsQAQCxALEAsAsQCxALEAEAsQCxALALEAsQCxABALEAsQCwCxALEAsQAQCxALEAsAsQCxALEAEAsQCxALALEAsQCxABALEAsQCwCxALEAsQAQCxALEAsQi1MAiAWIBYgFgFiAWIBYAIgFiAWIBYBYgFiAWACIBYgFiAWAWIBYgFgAiAWIBYgFgFiAWIBYAIgFiAWIBYBYgFiAWACIBYgFiAWAWIBYgFgAiAWIBYgFgFiAWIBYAIgFiAWIBYBYgFiAWACIBYgFiAWAWIBYgFgAiAWIBYgFgFgQNlWOS1s5MaDP5UQsCAvD5BwANRYgFiAWAGIBYgFiASAWIBYgFgBiAWIBYgEgFiAWIBYAYgFiAWIBIBYgFiAWAGIBYgFiASAWIBYgFgBiAWIBYgEgFiAWIBYAYgFiAWIBIBYgFlyy/D92ztNgQ9S1lwAAAABJRU5ErkJggg==';

function brandPng() {
  return Buffer.from(BRAND_PNG_B64, 'base64');
}

function isSafeRemoteImage(raw) {
  try {
    const u = new URL(raw);
    if (u.protocol !== 'https:') return false;
    const h = u.hostname.toLowerCase();
    if (h === 'localhost' || h.endsWith('.local') || h.endsWith('.internal')) return false;
    if (/^[\d.]+$/.test(h) || h.includes(':')) return false; // IPv4 / IPv6 directas
    return true;
  } catch (e) {
    return false;
  }
}

async function fetchRemoteImage(raw) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const r = await fetch(raw, { signal: ctrl.signal, redirect: 'error' });
    if (!r.ok) return null;
    const type = (r.headers.get('content-type') || '').split(';')[0].trim();
    if (!RASTER.test(type)) return null;
    const ab = await r.arrayBuffer();
    if (ab.byteLength > MAX_IMG_BYTES) return null;
    return { buf: Buffer.from(ab), mime: type };
  } finally {
    clearTimeout(timer);
  }
}

module.exports = async (req, res) => {
  const token = String((req.query && req.query.pres) || '').trim();
  let buf = null;
  let mime = 'image/png';

  if (token && token !== 'rental') {
    try {
      const r = await fetch(`${SB_URL}/rest/v1/system_data?id=eq.main&select=payload`, {
        headers: { apikey: SB_KEY, Authorization: 'Bearer ' + SB_KEY }
      });
      const rows = await r.json();
      const data = (rows && rows[0] && rows[0].payload && rows[0].payload.data) || {};
      const p = (data.presupuestos || []).find(x => String(x.token) === token || String(x.id) === token);
      const raw = p && (p.fotoDespues || p.fotoAntes);

      if (raw && typeof raw === 'string' && raw.startsWith('data:')) {
        const m = raw.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
        if (m && RASTER.test(m[1])) {
          const b = Buffer.from(m[2], 'base64');
          if (b.length && b.length <= MAX_IMG_BYTES) {
            buf = b;
            mime = m[1];
          }
        }
      } else if (raw && typeof raw === 'string' && isSafeRemoteImage(raw)) {
        const img = await fetchRemoteImage(raw);
        if (img) {
          buf = img.buf;
          mime = img.mime;
        }
      }
    } catch (e) {}
  }

  if (!buf || !buf.length) {
    buf = brandPng();
    mime = 'image/png';
  }
  res.setHeader('Content-Type', mime);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Cache-Control', 'public, max-age=300');
  res.status(200).send(buf);
};
